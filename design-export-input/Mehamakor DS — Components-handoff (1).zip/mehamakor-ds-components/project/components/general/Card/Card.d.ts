import * as React from 'react';

/**
 * Card — from mehamakor-frontend@1.0.0.
 */
export interface CardProps {
  [key: string]: unknown;
}

export declare const Card: React.ComponentType<CardProps>;
