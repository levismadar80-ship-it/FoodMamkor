Button from mehamakor-frontend. Use via `window.MehamakorDS.Button` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<DSProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Related

`ButtonSpinner`
